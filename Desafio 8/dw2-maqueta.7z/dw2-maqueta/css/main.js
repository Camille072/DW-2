public class ECommerce {
    public static void main(String[] args) }
        // Crear un array de productos
        Producto[4] = new Producto[4];
static        // Crear un array de productos
     productos = new Producto[4];// Agregar información de productos
        productos[0] = new Producto ("sillon blanco $1000")
        productos[1] = new Producto("mesa $500");
        productos[2] = new Producto("jean negro $200");
        productos[3] = new Producto("zapatillas converse $700") 
        // Recorrer el array de productos y mostrar la información
        for (Producto producto : productos) {
            String mensaje = "Nombre: " + producto.getNombre("") + ", Precio:" + producto.getPrecio();
            if (producto.() != null) {
                mensaje +=  +
            }
            System.out.println(mensaje);
        }
class Producto {
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio, String ) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
